<?php
require_once('config.php');
do_html_header('Register Page');//Pass the argument $title 

display_registration_from();
do_html_footer();

?>