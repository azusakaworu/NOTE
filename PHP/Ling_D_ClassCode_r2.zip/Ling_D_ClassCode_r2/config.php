<?php

require_once('output_fns.php');//html from footer header 
require_once('db_fns.php');//connect the database

require_once('data_valid_fns.php');//check email address by reg

require_once('user_auth_fns.php');// register function , login function 

//require_once('url_fns.php');


?>